<?php 

if(isset($_POST['submit'])){

        session_start();

        unset($_SESSION['username']);
        unset($_SESSION['permissions']);
        unset($_SESSION['message']);
        unset($_SESSION['Welcome']);

        $redirect_page = 'http://therealpi.co.nf';
                                
        header('Location: '.$redirect_page);
}

?>


<div id="side">
<aside id="news">
        <h4>Logout</h4>
        
        <form action="<?php echo $_SERVER['HOST_NAME']; ?>/logout.php" method="POST">
                <input type='submit' value='Logout' id="loginSubmit" name="submit" />
        </form>
        
</aside>
</div>