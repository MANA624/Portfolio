<?php

function hit_count() {
	
	$ip_address = $_SERVER['REMOTE_ADDR'];
        
	//echo $ip_address;

	$ipfile = 'ips.txt';
	$check_ips = file($ipfile);
	
	foreach($check_ips as $address){
		//echo $address;
		$address = trim($address);
		if($ip_address == $address){
			//echo 'IP address at '.$address.' already exists';
			return;
		}
	}
	
	$filename = 'views.txt';
	$reading = fopen($filename, 'r');
	$current_hits = fread($reading, filesize($filename));
	fclose($reading);
	
	$current_hits++;
	
	$update = fopen($filename, 'w');
	fwrite($update, $current_hits);
	fclose($update);
	
	$updateIP = fopen($ipfile, 'a');
	fwrite($updateIP, $ip_address."\n");
	fclose($updateIP);
	
}

hit_count();

?>